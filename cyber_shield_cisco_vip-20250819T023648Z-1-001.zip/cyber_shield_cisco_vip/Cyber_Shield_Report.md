# Cyber Shield: Defending the Network — End-to-End Submission

**Date:** 2025-08-18  
**Author:** Jo (Student)  
**Program:** Cisco VIP 2025 — Cyber Security

## Deliverables Overview
- Part 1 Topology: Part1_Topology.png
- Part 2 Hybrid Access: Part2_Hybrid_Access.png
- Part 3 Filtering & Monitoring: Part3_Filtering.png
- Risk Register: Risk_Register.csv
- Web Access Policy: Web_Access_Policy.txt


# PART 1 — Network Security Audit

## 1.1 Discovered Topology (see Part1_Topology.png)
Core components:
- ISP → Edge Router → Firewall → Core Switch → VLANs (Admin, Faculty, Student, Guest)
- Data Center: AD/LDAP, RADIUS, File Server, Application Server
- Wireless: WLC controlling APs in academic blocks
- Monitoring: IDS/IPS in-line at perimeter, Syslog/SIEM

## 1.2 Segmentation & Controls
- VLANs exist but require inter-VLAN ACLs to enforce least privilege.
- Firewall acts as north-south gate; limited east-west controls.
- Authentication: AD/LDAP for users; RADIUS/TACACS+ recommended for network devices.
- IDS/IPS present; signatures need tuning; span critical segments for visibility.

## 1.3 Attack Surface Mapping
Paths an attacker may exploit:
- Compromised student endpoint → lateral movement to internal apps if ACLs are weak.
- Wi-Fi misconfig (open SSID or shared PSK) → rogue AP association.
- Unpatched servers → exposed management ports (RDP/SSH) from student VLAN.
- DNS abuse → C2 traffic if DNS not filtered.

## 1.4 High-Risk Findings
- Flat zones between Student and Admin VLANs (R1).
- Weak admin authentication without MFA (R2).
- Uncontrolled browser extensions on lab PCs (R7).
- Limited logging coverage (R5).

## 1.5 Recommendations
- Enforce VLAN-based segmentation and inter-VLAN ACLs (deny any by default).
- Move management plane to a dedicated Mgmt VLAN; restrict SSH/HTTPS to IT only.
- Enable WPA2-Enterprise/WPA3-Enterprise (802.1X) and dynamic VLAN assignment.
- Implement DNS filtering; add NGFW app controls for P2P/VPN circumvention.
- Centralize logs to SIEM with weekly review and alerting rules.



# PART 2 — Secure Hybrid Access Architecture

## 2.1 Design Principles
- Zero Trust mindset: authenticate every session; least privilege access.
- Keep internal apps private; expose only VPN/IdP and optional identity-aware proxy.
- Simple, supportable by small IT staff.

## 2.2 Chosen Approach
- Primary: IPSec/SSL VPN terminator in DMZ with MFA (RADIUS/LDAP).
- Optional: Identity-Aware Proxy for selected web apps to minimize full-tunnel usage.
- No split tunneling for Faculty; Students remote access is limited to academic portals.

## 2.3 Authentication & Authorization Flow
1) User connects to VPN gateway (SSL/IPSec).
2) IdP (AD/LDAP + RADIUS) performs MFA.
3) On success, user is placed into role-based group (Faculty/Student).
4) Policy engine applies ACLs to internal resources; logs to SIEM.

## 2.4 Network Updates (see Part2_Hybrid_Access.png)
- Add “DMZ VPN Gateway” between Firewall and Core.
- Connect IdP and SIEM to collect auth and VPN logs.
- Optional path to SASE/Cloud SWG for internet egress security.

## 2.5 Fallback Strategies
- If VPN down: failover secondary gateway; read-only access to LMS via cloud proxy.
- If IdP down: break-glass accounts for IT with time-boxed access.
- If SIEM down: local log buffers on firewall/VPN; ship later.

## 2.6 Controls Mapping
- NIST CSF: PR.AC (access control), DE (detect), RS (respond).
- CIS Controls: 4 (Controlled Use of Admin Privileges), 12 (Network Infrastructure Management), 13 (Network Monitoring).




# PART 3 — Smart Web Filtering Policy

## 3.1 Solution Comparison
- DNS Filtering: Lightweight, easy, category-based. Blind to destination after DoH if unmanaged.
- L7 Firewall/NGFW: App-aware; blocks P2P/VPN signatures. Needs TLS/SNI visibility.
- Proxy/Cloud SWG: Strong URL/category control, file filtering, user-based policies. Requires PAC/agent.
- Endpoint Controls: Prevents local bypass; complements network enforcement.

## 3.2 Selected Blend
- DNS Filter + NGFW + Cloud SWG, with lab endpoints hardened.
- Time-based and role-based policies (see Web_Access_Policy.txt).

## 3.3 Enforcement Simulation (Cisco-like snippets)
### Inter-VLAN ACL Examples
ip access-list extended STUDENT_TO_DATACENTER
  deny ip any 10.10.50.0 0.0.0.255
  permit ip any 10.10.10.0 0.0.0.255 eq 443
  deny ip any any log

ip access-list extended FACULTY_TO_APPS
  permit tcp any host 10.10.60.20 eq 443
  deny ip any any log

interface vlan 30  ! Student VLAN
  ip access-group STUDENT_TO_DATACENTER in

interface vlan 20  ! Faculty VLAN
  ip access-group FACULTY_TO_APPS in

### VPN Group-Policy (ASA/FTD-style pseudocode)
group-policy FACULTY internal
  vpn-tunnel-protocol ssl-client
  split-tunnel-policy tunnelall
  webvpn
   anyconnect profiles FacultyProfile

group-policy STUDENTS internal
  vpn-tunnel-protocol ssl-client
  split-tunnel-policy excludespecified
  split-tunnel-network-list value AcademicPortals

### DNS Policy (Pseudo)
policy dns
  block categories malware, phishing, nrd, dga, p2p, vpn_proxy
  block categories social, streaming when time=Mon-Fri 09:00-17:00 and group=students
  allow category education

## 3.4 Logging & Alerts
- Send DNS/proxy/firewall/VPN logs to SIEM.
- Alerts: torrent signature matches, repeated block hits, VPN to non-campus endpoints.
- Weekly compliance dashboard: top violations, top blocked categories, top talkers.