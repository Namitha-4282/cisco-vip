Cisco VIP 2025 — Cyber Shield Deliverables

Files:
- Report (DOCX): present → Cyber_Shield_Report.docx
- Report (Markdown): Cyber_Shield_Report.md
- Part1_Topology.png
- Part2_Hybrid_Access.png
- Part3_Filtering.png
- Risk_Register.csv
- Web_Access_Policy.txt

How to Use:
1) Open the PNGs to understand the reference architectures.
2) Import the ACL samples and DNS/Proxy pseudo-policies into your lab notes.
3) Use the Risk_Register.csv for your presentation dashboard and prioritization.
4) The DOCX is ready to submit; otherwise use the Markdown.
