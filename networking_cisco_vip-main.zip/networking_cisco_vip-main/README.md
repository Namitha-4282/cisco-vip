# Cisco VIP 2025 — Networking Stream: Auto Topology + Validation + Simulation

**One-command runner** that parses router configs, generates a topology, validates configs,
analyzes load vs bandwidth, and runs a multithreaded Day-1 simulation with fault injection.

## Run
```bash
python -m src.main
```

Outputs are written to `out/`:
- `topology.png`: Auto-generated network topology
- `validation_report.csv`: Issues (MTU mismatches, loops, VLAN/gateway heuristics, protocol tips)
- `load_analysis.csv`: Link utilization & recommendations
- `simulation_day1.csv`: ARP/OSPF neighbor discovery stats
- `reachability.csv`: Components (with/without failure)
- `fault_injection.txt`: Which edge was failed
- `SUMMARY.txt`: Quick run info

## Architecture
- `parser.py` — IOS-like config parser (hostname, interfaces, IP/MTU/bandwidth, VLANs, OSPF/BGP)
- `topology.py` — Graph builder (IP-subnet linking, VLAN access links) + matplotlib visualization
- `validator.py` — Duplicate IP heuristics, MTU mismatch, VLAN mismatch, multi-gateway, loops, proto tips
- `load_analyzer.py` — Aggregates endpoint JSON loads to link-level utilization with actions
- `ipc.py` — FIFO-style IPC links + NodeThread
- `simulator.py` — Multithreaded Day-1 (ARP/OSPF hello), link-failure fault injection
- `main.py` — Orchestration

## Notes
- Parser infers links when interfaces share the same IP subnet; access links also inferred by matching VLAN IDs.
- Bandwidth field interpreted in kbps if present.
- Extend by adding CDP/LLDP parsing or more precise ACL/VLAN trunk logic.