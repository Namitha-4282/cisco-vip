import os
import networkx as nx
import matplotlib.pyplot as plt
from ipaddress import ip_network
from .utils import same_subnet

def build_graph(devices):
    G = nx.Graph()
    # Add device nodes
    for hn, dev in devices.items():
        G.add_node(hn, type="device")

    # Detect layer-2 access VLAN edges to switch devices (if both sides mention access vlan to same switch via description)
    # Primary edge inference: IP subnet matching between interfaces on different devices.
    interfaces = []
    for hn, dev in devices.items():
        for ifn, meta in dev["interfaces"].items():
            data = meta.copy()
            data["device"] = hn
            data["ifname"] = ifn
            interfaces.append(data)

    # IP-based linking
    for i in range(len(interfaces)):
        for j in range(i+1, len(interfaces)):
            a, b = interfaces[i], interfaces[j]
            if a.get("ip") and b.get("ip"):
                if same_subnet(a["ip"], a["mask"], b["ip"], b["mask"]):
                    n1, n2 = a["device"], b["device"]
                    bw = min(a.get("bandwidth") or 100000, b.get("bandwidth") or 100000)
                    mtu_mx = min(a.get("mtu") or 1500, b.get("mtu") or 1500)
                    G.add_edge(n1, n2, bandwidth=bw, mtu=mtu_mx, link="routed")
            # VLAN hint linking
            if a.get("access_vlan") and b.get("access_vlan"):
                if a["access_vlan"] == b["access_vlan"] and a["device"] != b["device"]:
                    G.add_edge(a["device"], b["device"], vlan=a["access_vlan"], link="access")

    return G

def draw_graph(G, out_path, title="Network Topology"):
    pos = nx.spring_layout(G, seed=7)
    labels = {}
    for u,v,d in G.edges(data=True):
        tag = ""
        if d.get("link")=="routed":
            tag += f"{d.get('bandwidth','?')}kbps, MTU {d.get('mtu','?')}"
        if d.get("link")=="access":
            tag += f"VLAN {d.get('vlan')}"
        labels[(u,v)] = tag
    plt.figure(figsize=(10,6))
    nx.draw(G, pos, with_labels=True, node_size=1600, font_size=9)
    nx.draw_networkx_edge_labels(G, pos, edge_labels=labels, font_size=7)
    plt.title(title)
    plt.savefig(out_path, bbox_inches='tight')
    plt.close()