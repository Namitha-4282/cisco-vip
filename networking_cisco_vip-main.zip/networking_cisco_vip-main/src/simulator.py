import os, json, time
import pandas as pd
import networkx as nx
from .ipc import IPCLink, NodeThread

def simulate(G, out_dir, fail_edge=None):
    # Build NodeThread for each node
    nodes = {n: NodeThread(n) for n in G.nodes()}
    # Create IPC links for each edge (undirected -> two directional FIFOs)
    for u,v,d in G.edges(data=True):
        if fail_edge and ((u==fail_edge[0] and v==fail_edge[1]) or (u==fail_edge[1] and v==fail_edge[0])):
            continue
        link_uv = IPCLink(f"{u}->{v}")
        link_vu = IPCLink(f"{v}->{u}")
        nodes[u].add_link(v, link_uv)
        nodes[v].add_link(u, link_vu)

    # start all
    for n in nodes.values():
        n.start()
    # run for a while
    time.sleep(6)
    # stop all
    for n in nodes.values():
        n.stop()
    time.sleep(0.5)

    # collect logs
    rows = []
    for n, th in nodes.items():
        rows.append({"node": n, "neighbors": ",".join(sorted(list(th.stats["neighbors"]))),
                     "ospf_adj": ",".join(sorted(list(th.stats["ospf_adj"]))),
                     "sent": th.stats["sent"], "recv": th.stats["recv"]})
    df = pd.DataFrame(rows, columns=["node","neighbors","ospf_adj","sent","recv"])
    df.to_csv(os.path.join(out_dir, "simulation_day1.csv"), index=False)

    # Simple reachability: node degree after failure
    H = G.copy()
    if fail_edge:
        try:
            H.remove_edge(*fail_edge)
        except Exception:
            pass
    comps = list(nx.connected_components(H))
    reach = {n:i for i,comp in enumerate(comps) for n in comp}
    pd.DataFrame([{"node":n,"component":reach[n]} for n in H.nodes()]).to_csv(os.path.join(out_dir,"reachability.csv"), index=False)

    return df, H