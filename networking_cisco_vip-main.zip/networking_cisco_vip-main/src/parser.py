import os
from .utils import INTF_RE, IP_RE, DESC_RE, MTU_RE, BW_RE, VLAN_RE, HOST_RE, OSPF_RE, BGP_RE, cidr

def parse_device_config(path):
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        lines = [l.rstrip() for l in f.readlines()]

    device = {
        "hostname": None,
        "interfaces": {},
        "protocols": {},
        "vlans": {},
        "path": path
    }

    current_intf = None
    for line in lines:
        m = HOST_RE.match(line)
        if m:
            device["hostname"] = m.group(1)

        m = INTF_RE.match(line)
        if m:
            current_intf = m.group(1)
            device["interfaces"][current_intf] = {
                "description": None,
                "ip": None,
                "mask": None,
                "cidr": None,
                "mtu": None,
                "bandwidth": None,
                "access_vlan": None
            }
            continue

        if current_intf:
            m = DESC_RE.match(line)
            if m:
                device["interfaces"][current_intf]["description"] = m.group(1)
            m = IP_RE.match(line)
            if m:
                ip, mask = m.group(1), m.group(2)
                device["interfaces"][current_intf]["ip"] = ip
                device["interfaces"][current_intf]["mask"] = mask
                device["interfaces"][current_intf]["cidr"] = cidr(ip, mask)
            m = MTU_RE.match(line)
            if m:
                device["interfaces"][current_intf]["mtu"] = int(m.group(1))
            m = BW_RE.match(line)
            if m:
                device["interfaces"][current_intf]["bandwidth"] = int(m.group(1))
            m = VLAN_RE.match(line)
            if m:
                device["interfaces"][current_intf]["access_vlan"] = m.group(1)

        m = OSPF_RE.match(line)
        if m:
            device["protocols"]["ospf"] = m.group(1)
        m = BGP_RE.match(line)
        if m:
            device["protocols"]["bgp"] = m.group(1)

    return device

def parse_all(conf_dir):
    devices = {}
    for root, _, files in os.walk(conf_dir):
        for fn in files:
            if fn.endswith(".dump"):
                d = parse_device_config(os.path.join(root, fn))
                if d["hostname"]:
                    devices[d["hostname"]] = d
    return devices