import re
from ipaddress import ip_network, ip_address

INTF_RE = re.compile(r'^interface\s+(\S+)', re.I)
IP_RE = re.compile(r'^\s*ip address\s+(\S+)\s+(\S+)', re.I)
DESC_RE = re.compile(r'^\s*description\s+(.+)', re.I)
MTU_RE = re.compile(r'^\s*mtu\s+(\d+)', re.I)
BW_RE = re.compile(r'^\s*bandwidth\s+(\d+)', re.I)
VLAN_RE = re.compile(r'^\s*switchport access vlan\s+(\d+)', re.I)
HOST_RE = re.compile(r'^\s*hostname\s+(\S+)', re.I)
OSPF_RE = re.compile(r'^\s*router ospf\s+(\d+)', re.I)
BGP_RE = re.compile(r'^\s*router bgp\s+(\d+)', re.I)

def mask_to_prefix(mask):
    # Convert dotted mask to prefix length
    return sum([bin(int(x)).count('1') for x in mask.split('.')])

def same_subnet(ip1, mask1, ip2, mask2):
    n1 = ip_network(f"{ip1}/{mask_to_prefix(mask1)}", strict=False)
    n2 = ip_network(f"{ip2}/{mask_to_prefix(mask2)}", strict=False)
    return n1.network_address == n2.network_address and n1.prefixlen == n2.prefixlen

def normalize_interface(name):
    return name.strip()

def cidr(ip, mask):
    return f"{ip}/{mask_to_prefix(mask)}"