import os, json
import pandas as pd
from datetime import datetime
from .parser import parse_all
from .topology import build_graph, draw_graph
from .validator import validate
from .load_analyzer import analyze_load
from .simulator import simulate

def run_all(conf_dir, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    devices = parse_all(conf_dir)
    # Topology
    G = build_graph(devices)
    topo_img = os.path.join(out_dir, "topology.png")
    draw_graph(G, topo_img, title="Auto-Generated Network Topology")
    # Validation
    val_df = validate(devices, G)
    val_df.to_csv(os.path.join(out_dir,"validation_report.csv"), index=False)
    # Load analysis
    endpoints_json = os.path.join(conf_dir, "endpoints.json")
    if os.path.exists(endpoints_json):
        load_df = analyze_load(G, endpoints_json)
        load_df.to_csv(os.path.join(out_dir,"load_analysis.csv"), index=False)
    else:
        load_df = pd.DataFrame()
    # Simulation Day-1
    sim_df, H = simulate(G, out_dir=out_dir)
    # Fault injection (link failure demo)
    edges = list(G.edges())
    fail = edges[0] if edges else None
    if fail:
        simulate(G, out_dir=out_dir, fail_edge=fail)
        with open(os.path.join(out_dir,"fault_injection.txt"),"w") as f:
            f.write(f"Simulated failure on edge: {fail}\n")
    # Summary
    with open(os.path.join(out_dir,"SUMMARY.txt"),"w") as f:
        f.write(f"Run at: {datetime.now().isoformat()}\n")
        f.write(f"Devices parsed: {list(devices.keys())}\n")
        f.write(f"Edges: {list(G.edges())}\n")
        if fail:
            f.write(f"Fault injected on edge: {fail}\n")
    return {"devices": list(devices.keys()), "edges": list(G.edges())}

if __name__ == "__main__":
    BASE = os.path.dirname(os.path.dirname(__file__))
    conf = os.path.join(BASE, "Conf")
    out = os.path.join(BASE, "out")
    res = run_all(conf, out)
    print("OK", res)