import threading, queue, time, random

class IPCLink:
    def __init__(self, name, capacity_pps=1000):
        self.name = name
        self.q = queue.Queue(maxsize=capacity_pps)
    def send(self, pkt):
        try:
            self.q.put_nowait(pkt)
            return True
        except queue.Full:
            return False
    def recv(self, timeout=0.1):
        try:
            return self.q.get(timeout=timeout)
        except queue.Empty:
            return None

class NodeThread(threading.Thread):
    def __init__(self, name):
        super().__init__(daemon=True)
        self.name = name
        self.links = {}  # neighbor -> IPCLink
        self.running = False
        self.stats = {"sent":0,"recv":0,"neighbors":set(),"ospf_adj":set()}
        self.log = []
    def add_link(self, neighbor, link: IPCLink):
        self.links[neighbor] = link
    def run(self):
        self.running = True
        t0 = time.time()
        # Periodic OSPF hello + ARP broadcast simulation
        while self.running and time.time()-t0 < 5.0:
            # Send OSPF hello to neighbors
            for n, l in self.links.items():
                pkt = {"type":"OSPF_HELLO","from":self.name,"to":n,"ts":time.time()}
                if l.send(pkt):
                    self.stats["sent"] += 1
            # Broadcast ARP ("who-has") to discover neighbors
            for n, l in self.links.items():
                pkt = {"type":"ARP_REQ","from":self.name,"to":n,"ts":time.time()}
                l.send(pkt); self.stats["sent"] += 1
            # Receive
            for n, l in self.links.items():
                for _ in range(5):
                    pkt = l.recv(timeout=0.01)
                    if pkt:
                        self.stats["recv"] += 1
                        if pkt["type"]=="OSPF_HELLO":
                            self.stats["ospf_adj"].add(pkt["from"])
                        if pkt["type"]=="ARP_REQ":
                            self.stats["neighbors"].add(pkt["from"])
            time.sleep(0.2)
        self.log.append(f"{self.name}: neighbors={sorted(self.stats['neighbors'])}, ospf_adj={sorted(self.stats['ospf_adj'])}, sent={self.stats['sent']}, recv={self.stats['recv']}")
    def stop(self):
        self.running = False