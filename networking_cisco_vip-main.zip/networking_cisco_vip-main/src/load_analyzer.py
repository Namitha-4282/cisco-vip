import pandas as pd
import json

def analyze_load(G, endpoints_json):
    with open(endpoints_json,'r') as f:
        ep = json.load(f)

    # Aggregate per VLAN peak loads
    vlan_load = {}
    for vid, vmeta in ep.get("vlans",{}).items():
        total = 0
        for e in vmeta.get("endpoints",[]):
            for app in e.get("apps",[]):
                total += app.get("peak_mbps",0)
        vlan_load[vid] = total  # Mbps

    # Map VLANs to devices (edges from access links)
    recs = []
    for u, v, d in G.edges(data=True):
        if d.get("link") == "access":
            vlan = d.get("vlan")
            load = vlan_load.get(vlan,0)
            # treat bandwidth attribute in kbps if present; convert to Mbps
            bw_mbps = d.get("bandwidth", 100000)/1000.0 if d.get("bandwidth") else 100
            stress = load / max(bw_mbps, 1)
            action = "OK"
            note = "Capacity sufficient"
            if stress > 0.8 and stress <= 1.0:
                action = "WATCH"
                note = "Near capacity; consider QoS/prioritization"
            if stress > 1.0:
                action = "OVER"
                note = "Over capacity; recommend load balancing or LAG"
            recs.append({"link": f"{u}<->{v} (VLAN {vlan})", "load_mbps": load, "capacity_mbps": bw_mbps, "utilization": round(stress,2), "action": action, "note": note})
    df = pd.DataFrame(recs, columns=["link","load_mbps","capacity_mbps","utilization","action","note"])
    return df