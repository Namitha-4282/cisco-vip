import pandas as pd
from collections import defaultdict
from .utils import same_subnet

def validate(devices, G):
    issues = []

    # Duplicate IPs in same VLAN/subnet
    cidr_map = defaultdict(list)
    for hn, dev in devices.items():
        for ifn, meta in dev["interfaces"].items():
            if meta.get("cidr"):
                cidr_map[meta["cidr"]].append((hn, ifn, meta.get("access_vlan")))

    for cidr, lst in cidr_map.items():
        ips = defaultdict(int)
        for hn, ifn, vlan in lst:
            # We don't track specific IPs here, but if more than 2 on same /30 or duplicates, flag potential issue
            ips[cidr] += 1
        if ips[cidr] > 2 and "/30" in cidr:
            issues.append(("IP_DUPLICATE_OR_OVERUSE", f"Too many IPs on /30 subnet {cidr}", "High", "Check point-to-point design"))
    
    # MTU mismatches on edges
    for u, v, d in G.edges(data=True):
        # fetch actual interface mtus (min used in edge); we flag if devices declare different MTUs on same subnet
        # We approximate by checking if there exist pair of interfaces in same subnet with different MTUs
        mtus = set()
        for ifn, meta in devices[u]["interfaces"].items():
            for ifn2, meta2 in devices[v]["interfaces"].items():
                if meta.get("ip") and meta2.get("ip"):
                    if same_subnet(meta["ip"], meta["mask"], meta2["ip"], meta2["mask"]):
                        if meta.get("mtu") and meta2.get("mtu") and meta["mtu"] != meta2["mtu"]:
                            mtus.add((meta["mtu"], meta2["mtu"]))
        if mtus:
            issues.append(("MTU_MISMATCH", f"{u} <-> {v} have MTU mismatch: {list(mtus)}", "Medium", "Align MTUs across link"))

    # VLAN label inconsistencies on access links
    for u, v, d in G.edges(data=True):
        if d.get("link") == "access":
            vlans_u = set([meta.get("access_vlan") for meta in devices[u]["interfaces"].values() if meta.get("access_vlan")])
            vlans_v = set([meta.get("access_vlan") for meta in devices[v]["interfaces"].values() if meta.get("access_vlan")])
            if not vlans_u.intersection(vlans_v):
                issues.append(("VLAN_MISMATCH", f"{u} <-> {v} access link VLANs differ", "Medium", "Ensure same VLAN ID"))

    # Incorrect gateway heuristics: multiple routers on same user VLAN
    vlan_router_count = defaultdict(set)
    for hn, dev in devices.items():
        for ifn, meta in dev["interfaces"].items():
            if meta.get("access_vlan") and meta.get("ip"):
                vlan_router_count[meta["access_vlan"]].add(hn)
    for vlan, routers in vlan_router_count.items():
        if len(routers) > 1:
            issues.append(("MULTI_GATEWAY", f"Multiple L3 gateways detected on VLAN {vlan}: {', '.join(routers)}", "High", "Keep single SVI/L3 gateway per VLAN or use VRRP/HSRP properly"))

    # Protocol recommendation: if any device runs BGP and OSPF across same AS, suggest BGP at edges only
    runs_bgp = any(["bgp" in d.get("protocols", {}) for d in devices.values()])
    runs_ospf = any(["ospf" in d.get("protocols", {}) for d in devices.values()])
    if runs_bgp and runs_ospf:
        issues.append(("PROTO_RECOMMEND", "Consider using OSPF intra-campus and BGP only at edge/peering", "Info", "Segregate IGP/EGP roles"))

    # Loop detection
    import networkx as nx
    try:
        cycles = list(nx.cycle_basis(G))
        if cycles:
            issues.append(("LOOP_DETECTED", f"Graph cycles present: {cycles}", "Info", "Ensure STP on L2, proper routing on L3"))
    except Exception:
        pass

    df = pd.DataFrame(issues, columns=["Issue","Detail","Severity","Recommendation"])
    return df